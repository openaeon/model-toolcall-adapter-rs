Model Toolcall Adapter RS

Run:
  macOS/Linux:
    chmod +x ./model-toolcall-adapter-rs
    ./model-toolcall-adapter-rs

  Windows:
    .\model-toolcall-adapter-rs.exe

Default UI:
  http://127.0.0.1:8787/ui

Useful env:
  ADAPTER_BIND=127.0.0.1:8787
  ADAPTER_API_KEY=your-key
  ADAPTER_UPSTREAM_MODEL=deepseek-web/reasoner

Local config:
  ~/.model-toolcall-adapter/config.json
